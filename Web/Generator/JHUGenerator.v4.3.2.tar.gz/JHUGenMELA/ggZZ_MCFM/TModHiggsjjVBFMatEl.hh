
#ifndef _TMODHIGGSJJVBFMATEL_HH_
#define _TMODHIGGSJJVBFMATEL_HH_

extern "C" {
  void __modhiggsvbf_MOD_evalamp_vbfh(double P[5][4], double Hvvcoupl[4][2], double MatElSq[11][11]);
}

#endif

