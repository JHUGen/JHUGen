
#ifndef _TMODHIGGSJJMATEL_HH_
#define _TMODHIGGSJJMATEL_HH_

extern "C" {
  void __modhiggsjj_MOD_evalamp_gg_jjh(double P[5][4], double Hggcoupl[3][2], double MatElSq[11][11]);
}

#endif

