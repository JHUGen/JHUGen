
#ifndef _TMODVHIGGSMATEL_HH_
#define _TMODVHIGGSMATEL_HH_

extern "C" {
  void __modvhiggs_MOD_evalamp_vhiggs(int id[9], double helicity[9], double MomExt[9][4], double Hvvcoupl[32][2], double mass[2][9], double* me2);
}

#endif
