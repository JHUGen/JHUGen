{
  gSystem->Load("libgfortran.so");
  gSystem->Load("libPhysics.so");
  gSystem->Load("libEG.so");
  gSystem->Load("./libmcfm_6p8.so");
  gSystem->Load("./libME.so");
}
