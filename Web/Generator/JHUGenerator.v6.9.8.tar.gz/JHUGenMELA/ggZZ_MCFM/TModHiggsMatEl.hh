
#ifndef _TMODHIGGSMATEL_HH_
#define _TMODHIGGSMATEL_HH_

extern "C" {
  void __modhiggs_MOD_evalamp_gg_h_vv(double P[6][4], double *MReso,  double *GaReso, double Hggcoupl[3][2], double Hvvcoupl[39][2], int *MYIDUP, double *MatElSq);
}

#endif

