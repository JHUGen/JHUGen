
#ifndef _TMODHIGGSJJMATEL_HH_
#define _TMODHIGGSJJMATEL_HH_

extern "C" {
  void __modhiggsjj_MOD_evalamp_sbfh(double P[5][4], double Hggcoupl[3][2], double MatElSq[11][11]);
  void __modhiggsjj_MOD_evalamp_wbfh(double P[5][4], double Hvvcoupl[24][2], double MatElSq[11][11]);
}

#endif

