#. /afs/cern.ch/sw/lcg/contrib/gcc/4.3/x86_64-slc5/setup.sh
#export ROOTSYS=/afs/cern.ch/sw/lcg/app/releases/ROOT/5.32.00/x86_64-slc5-gcc43-opt/root/
. /afs/cern.ch/sw/lcg/contrib/gcc/4.6/x86_64-slc6/setup.sh
export ROOTSYS=/afs/cern.ch/sw/lcg/app/releases/ROOT/5.34.00/x86_64-slc6-gcc46-opt/root/
export PATH=$HOME/bin:$ROOTSYS/bin:$PATH
export LD_LIBRARY_PATH=$ROOTSYS/lib:$LD_LIBRARY_PATH