#ifndef boost_h
#define boost_h

#include <math.h>

extern void inline boost_(double*, double*, double*);

#endif
